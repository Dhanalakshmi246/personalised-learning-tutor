import streamlit as st
import openai
import os

# Load your OpenAI API key from environment variable for security
openai.api_key = os.getenv("OPENAI_API_KEY")

st.set_page_config(page_title="📚 Personalized AI Tutor")

st.title("📚 Personalized AI Tutor")

st.write("""
Welcome to your AI-powered tutor!  
Get explanations tailored to your level — Beginner, Intermediate, or Advanced.
""")

# Sidebar options
user_level = st.sidebar.selectbox(
    "Your learning level:",
    ["Beginner", "Intermediate", "Advanced"]
)

topic = st.sidebar.text_input(
    "Topic:",
    value="Python functions"
)

user_question = st.text_area(
    "Ask your question:",
    placeholder="E.g., How do I write a function in Python?"
)

if st.button("Get Explanation"):
    if not user_question.strip():
        st.warning("Please enter a question.")
    else:
        prompt = (
            f"You are an expert tutor. Explain this question to a {user_level} student. "
            f"Topic: {topic}. Question: {user_question}. "
            f"Give a clear, step-by-step explanation."
        )

        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a helpful tutor."},
                {"role": "user", "content": prompt}
            ]
        )

        answer = response.choices[0].message.content
        st.write("### ✏️ Explanation")
        st.write(answer)
