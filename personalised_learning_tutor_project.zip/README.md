# 📚 Personalized AI Tutor

An AI-powered interactive tutor using OpenAI GPT-4 and Streamlit.  
It provides customized explanations based on the learner’s level and topic.

## ✅ Features

- Tailors answers for Beginner, Intermediate, or Advanced learners.
- Explains any topic or question with step-by-step clarity.
- Easy-to-use web interface powered by Streamlit.

## 🚀 How to Run Locally

1. **Clone this repository:**

   ```bash
   git clone https://github.com/YOUR_USERNAME/personalised-learning-tutor.git
   cd personalised-learning-tutor
   ```

2. **Create a virtual environment (recommended):**

   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies:**

   ```bash
   pip install -r requirements.txt
   ```

4. **Set your OpenAI API key as an environment variable:**

   ```bash
   export OPENAI_API_KEY="YOUR_API_KEY"    # macOS/Linux
   setx OPENAI_API_KEY "YOUR_API_KEY"      # Windows (PowerShell)
   ```

5. **Run the app:**

   ```bash
   streamlit run app.py
   ```

## 🛠️ Tech Stack

- Python
- Streamlit
- OpenAI API

## 📌 Deployment

You can deploy this on [Streamlit Community Cloud](https://streamlit.io/cloud) for free!  
Just make sure to set your `OPENAI_API_KEY` in the Streamlit secrets.

## 🪪 License

This project is open source under the MIT License.

**Made with ❤️ using GPT-4**
